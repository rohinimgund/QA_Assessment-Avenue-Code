package com.qa.pages;

import com.qa.util.TestBase;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import javax.swing.*;
import javax.swing.text.html.HTMLDocument;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class MyTasksPage extends TestBase {

    @FindBy(xpath = "//a[contains(text(),'My tasks')]")
    WebElement myTasksLink;

    @FindBy(xpath = "//a[@href='#']")
    WebElement userNameLabel;

    @FindBy(xpath = "//h1")
    WebElement displayMessageForLoggedInUser;

    @FindBy(xpath = "//div[@class='input-group']//input[@id='new_task']")
    WebElement newTaskDescription;

    @FindBy(xpath = "//div[@class='input-group']//span[@class='input-group-addon glyphicon glyphicon-plus']")
    WebElement addTaskButton;

    @FindAll(@FindBy(xpath = "//table[@class='table']/tbody/tr"))
    List<WebElement> newTasksList;

    @FindAll(@FindBy(xpath="//table[@class='table']/tbody/tr/td/button[@class='btn btn-xs btn-danger']"))
    List<WebElement> removeTaskButton;

    @FindAll(@FindBy(xpath ="//table[@class='table']/tbody/tr/td/button[contains(text(),'Remove SubTask')]"))
    List<WebElement> removeSubTaskButton;

    @FindBy(xpath = "//table[@class='table']/tbody/tr/td/button[@class='btn btn-xs btn-primary ng-binding']")
    List<WebElement> manageSubTasksButton;

    @FindBy(xpath = "//div[@class='modal-content']")
    WebElement popUpWindow;

    @FindBy(xpath = "//h3[@class='modal-title ng-binding']")
    WebElement taskIDOnPopUpWindow;

    @FindBy(xpath = "//div[@class='modal-body ng-scope']/form/textarea[@id='edit_task']")
    WebElement taskDesscriptionOnPopUpWindow;

    @FindAll(@FindBy(xpath = "//table[@class='table']/tbody/tr"))
    List<WebElement> subTaskList;

    @FindBy(xpath = "//form[@name='sub_task_form']/div/input[@id='new_sub_task']")
    WebElement subTaskDescriptionOnPopUpWindow;

    @FindBy(xpath = "//form[@name='sub_task_form']/div/p/input[@id='dueDate']")
    WebElement dueDateOnPopUpWindow;

    @FindBy(xpath = "//form[@name='sub_task_form']/div/button[@id='add-subtask']")
    WebElement addSubTaskButtonOnPopUpWindow;

    //initializing page objects
    public MyTasksPage()
    {
        PageFactory.initElements(driver, this);
    }

    //Actions

    public String validateMyTasksPageTitle()
    {
        return driver.getTitle();
    }

    public boolean validateMyTasksLink()
    {
        return myTasksLink.isDisplayed();
    }

    public boolean validateManageSubTasksButton()
    {
        return manageSubTasksButton.get(0).isDisplayed();
    }

    public void ClickOnManageSubTasksButton()
    {
        manageSubTasksButton.get(0).click();
    }
    public MyTasksPage ClickOnMyTasks()
    {
        myTasksLink.click();
        return new MyTasksPage();
    }

    public String verifyDisplayMessageForLoggedInUser()
    {
        return displayMessageForLoggedInUser.getText();
    }

    public void enterDescriptionForNewTask(String details)
    {
        newTaskDescription.sendKeys(details);
    }

    public String checkNewTaskDescription()
    {
        return newTaskDescription.getAttribute("value");
    }

    public String checkSubTaskDescription()
    {
        return subTaskDescriptionOnPopUpWindow.getAttribute("value");
    }

    public String checkDueDate()
    {
        return dueDateOnPopUpWindow.getAttribute("value");
    }

    public boolean verifyNewTaskDescription(String details)
    {
        return details.equals(newTaskDescription.getAttribute("value"));
    }

    public void ClickOnAddTaskButton()
    {
        addTaskButton.click();
    }

    public void hitEnterButton()
    {
        newTaskDescription.sendKeys(Keys.ENTER);
    }

    public int getNumberOfNewTasks()
    {
        return newTasksList.size();
    }

    public int getNumberOfSubTasks()
    {
        return subTaskList.size();
    }

    public void ClickOnRemoveTaskButton()
    {
        removeTaskButton.get(0).click();
    }

    public void ClickOnRemoveSubTaskButton()
    {
        removeSubTaskButton.get(0).click();
    }

    public Set<String> getPopUpWindow()
    {
        Set<String> handles = driver.getWindowHandles();
        return handles;
    }

    public void verifyPopUpWindow()
    {
        Set<String> handles = getPopUpWindow();
        String parentWindowHandler = driver.getWindowHandle();
        String popUpWindowHandler = null;
        Iterator<String> iterator = handles.iterator();
        while(iterator.hasNext())
            popUpWindowHandler = iterator.next();
        driver.switchTo().window(popUpWindowHandler);
        Assert.assertTrue(popUpWindow.isDisplayed());
    }

    public void verifyTaskIDOnPopUpWindow()
    {
        String str = taskIDOnPopUpWindow.getText();
        int k = str.indexOf(" ", str.indexOf(" ") + 1);
        String actualTaskID = str.substring(k);
        Assert.assertEquals(false, actualTaskID.isEmpty());
    }

    public void verifyTaskDescriptionOnPopUpWindow()
    {
        taskDesscriptionOnPopUpWindow.isDisplayed();
    }

    public String verifySubTaskDescriptionPlaceHolderDetailsOnPopUpWindow()
    {
        return subTaskDescriptionOnPopUpWindow.getAttribute("placeholder");
    }

    public boolean verifySubTaskDescription(String details)
    {
        return details.equals(subTaskDescriptionOnPopUpWindow.getAttribute("value"));
    }

    public boolean verifySubTaskDueDate(String details)
    {
        return details.equals(dueDateOnPopUpWindow.getAttribute("value"));
    }

    public void clickOnAddSubTaskButton()
    {
        addSubTaskButtonOnPopUpWindow.click();
    }

    public void entersDetailsForSubTask(String description, String date)
    {
        subTaskDescriptionOnPopUpWindow.sendKeys(description);
        dueDateOnPopUpWindow.sendKeys(date);
    }


}
