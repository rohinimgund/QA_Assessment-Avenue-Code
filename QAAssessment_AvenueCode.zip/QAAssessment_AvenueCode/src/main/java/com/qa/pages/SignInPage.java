package com.qa.pages;

import com.qa.util.TestBase;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignInPage extends TestBase {

    //Page Factory - OR:
    @FindBy(xpath="//div[@class='form-group']//input[@id='user_email']")
    WebElement userEmail;

    @FindBy(xpath="//div[@class='form-group']//input[@id='user_password']")
    WebElement userPassword;

    @FindBy(xpath="//input[@class='btn btn-primary']")
    WebElement loginBtn;

    @FindBy(xpath = "//a[contains(text(),'My Tasks')]")
    WebElement myTasksLink;

    @FindBy(xpath = "//a[contains(text(),'Home')]")
    WebElement homeLink;


    //initializing the page objects
    public SignInPage()
    {
        PageFactory.initElements(driver, this);
    }

    //Actions

    public String verifySignInPageTitle()
    {
        return driver.getTitle();
    }

    public boolean validateMyTasksLink()
    {
        return myTasksLink.isDisplayed();
    }

    public boolean validateHomeLink()
    {
        return homeLink.isDisplayed();
    }

    public MyTasksPage ClickOnMyTasks()
    {
        myTasksLink.click();
        return new MyTasksPage();
    }

    public HomePage login(String umail, String pwd)
    {
        userEmail.sendKeys(umail);
        userPassword.sendKeys(pwd);
        loginBtn.click();
        return new HomePage();
    }
}
