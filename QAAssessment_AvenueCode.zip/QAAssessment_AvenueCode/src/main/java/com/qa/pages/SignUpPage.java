package com.qa.pages;

import com.qa.util.TestBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignUpPage extends TestBase {

    @FindBy(xpath = "//a[contains(text(),'My Tasks')]")
    WebElement myTasksLink;

    //initializing the page objects
    public SignUpPage()
    {
        PageFactory.initElements(driver, this);
    }

    //Actions

    public String verifySignUpPageTitle()
    {
        return driver.getTitle();
    }

    public boolean validateMyTasksLink()
    {
        return myTasksLink.isDisplayed();
    }

}
