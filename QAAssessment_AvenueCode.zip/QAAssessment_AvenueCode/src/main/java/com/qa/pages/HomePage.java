package com.qa.pages;

import com.qa.util.TestBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends TestBase {

    // Page Factory - OR:
    @FindBy(xpath = "//a[contains(text(),'Sign In')]")
    WebElement signInLink;

    @FindBy(xpath = "//a[contains(text(),'My Tasks')]")
    WebElement myTasksLink;

    @FindBy(xpath = "//a[contains(text(),'Register')]")
    WebElement registerLink;

    @FindBy(xpath = "//a[contains(@class,'btn btn-lg btn-success')]")
    WebElement signUpButton;

    @FindBy(xpath = "//a[contains(@class,'btn btn-lg btn-danger')]")
    WebElement testDescriptionButton;


    //initializing the page objects
    public HomePage()
    {
        PageFactory.initElements(driver, this);
    }

    //Actions

    public String validateHomePageTitle()
    {
        return driver.getTitle();
    }

    public boolean validateMyTasksLink()
    {
        return myTasksLink.isDisplayed();
    }

    public SignInPage ClickOnSignIn()
    {
        signInLink.click();
        return new SignInPage();
    }

    public MyTasksPage ClickOnMyTasks()
    {
        myTasksLink.click();
        return new MyTasksPage();
    }

    public SignUpPage ClickOnRegister()
    {
        registerLink.click();
        return new SignUpPage();
    }

    public SignUpPage ClickOnSignUp()
    {
        signUpButton.click();
        return new SignUpPage();
    }

}
