package com.qa.stepDefinations;

import com.qa.pages.HomePage;
import com.qa.pages.MyTasksPage;
import com.qa.pages.SignInPage;
import com.qa.pages.SignUpPage;
import com.qa.util.TestBase;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class LoginSteps extends TestBase
{
    HomePage homePage;
    SignInPage signInPage;
    MyTasksPage myTasksPage;
    SignUpPage signUpPage;
    int oountOfNewTasks;
    int oountOfSubTasks;

    @Given("^user opens browser")
    public void userOpensBrowser()
    {
        initialization();
    }

    @And("^user is on Home page$")
    public void userIsOnHomePage() throws Throwable {
        homePage = new HomePage();
        String homeTitle = homePage.validateHomePageTitle();
        Assert.assertEquals("ToDo Rails and Angular",homeTitle);
    }

    @Then("^Validate My Tasks Button on Home page$")
    public void validateMyTasksButtonOnHomePage() throws Throwable {
        boolean isMyTasksButtonPresent = homePage.validateMyTasksLink();
        Assert.assertTrue(isMyTasksButtonPresent);
    }

    @Then("^close the browser$")
    public void closeTheBrowser() throws Throwable {
        quit();
    }

    @And("^user clicks on SignIn button$")
    public void userClicksOnSignInButton() throws Throwable {
        signInPage = homePage.ClickOnSignIn();
    }

    @And("^SignIn page is displayed$")
    public void signinPageIsDisplayed() throws Throwable {
        String signInPageTitle = signInPage.verifySignInPageTitle();
        Assert.assertEquals("ToDo Rails and Angular",signInPageTitle);
    }

    @Then("^Validate My Tasks Button on SignIn page$")
    public void validateMyTasksButtonOnSignInPage() throws Throwable {
        boolean isMyTasksButtonPresent = signInPage.validateMyTasksLink();
        Assert.assertTrue(isMyTasksButtonPresent);
    }

    @And("^user logs into the application$")
    public void userLogsIntoTheApplication() throws Throwable {
        homePage = signInPage.login(prop.getProperty("email"), prop.getProperty("password"));
    }

    @And("^user is logged in and on home page$")
    public void userIsLoggedInAndOnHomePage() throws Throwable {
        String homeTitle = homePage.validateHomePageTitle();
        Assert.assertEquals("ToDo Rails and Angular",homeTitle);
    }

    @And("^user clicks on My Tasks button present on Home page$")
    public void userClicksOnMyTasksButtonPresentOnHomePage() throws Throwable {
        myTasksPage = homePage.ClickOnMyTasks();
    }

    @Then("^My Tasks Page is displayed$")
    public void myTasksPageIsDisplayed() throws Throwable {
        String myTasksPageTitle = myTasksPage.validateMyTasksPageTitle();
        Assert.assertEquals("ToDo Rails and Angular",myTasksPageTitle);
    }

    @And("^user clicks on SignUp button$")
    public void userClicksOnSignUpButton() throws Throwable {
        signUpPage = homePage.ClickOnSignUp();
    }

    @And("^Validate My Tasks Button on SignUp page$")
    public void validateMyTasksButtonOnSignUpPage() throws Throwable {
        boolean isMyTasksButtonPresent = signUpPage.validateMyTasksLink();
        Assert.assertTrue(isMyTasksButtonPresent);
    }

    @Then("^Validate display message for logged in user on MyTasks page$")
    public void validateDisplayMessageForLoggedInUserOnMyTeasksPage() throws Throwable {
        String actualDisplayMessage = myTasksPage.verifyDisplayMessageForLoggedInUser();
        Assert.assertEquals("Hey Rohini Manohar Gund, this is your todo list for today:", actualDisplayMessage);
    }

    @Then("^user enters ([^\"]*)$")
    public void userEntersNewTaskDescription(String newTaskDescription) throws Throwable {
            myTasksPage.enterDescriptionForNewTask(newTaskDescription);
            oountOfNewTasks = myTasksPage.getNumberOfNewTasks();
    }

    @Then("^user hit enter button$")
    public void userHitEnterButton() throws Throwable {
            oountOfNewTasks = myTasksPage.getNumberOfNewTasks();
            myTasksPage.hitEnterButton();
    }

    @Then("^new task should be created and appended in the task list$")
    public void newTaskShouldBeCreatedAndAppendedInTheTaskList() throws Throwable {
            int actualNumberOfTasks = myTasksPage.getNumberOfNewTasks();
            oountOfNewTasks++;
            Assert.assertEquals(oountOfNewTasks,actualNumberOfTasks);
    }

    @Then("^user clicks on add task button$")
    public void clickOnAddTaskButtonDenotedAs() throws Throwable {
            myTasksPage.ClickOnAddTaskButton();
    }

    @Then("^new task should not get created$")
    public void newTaskShouldNotGetCreated() throws Throwable {
        int actualNumberOfTasks = myTasksPage.getNumberOfNewTasks();
        Assert.assertEquals(oountOfNewTasks,actualNumberOfTasks);
    }

    @Then("^remove newly added new task with ([^\"]*)$")
    public void removeNewlyAddedNewTaskWithNewTaskDescription(String newTaskDescription) throws Throwable {
        String actualNewTaskDescription = myTasksPage.checkNewTaskDescription();
        myTasksPage.ClickOnRemoveTaskButton();
        Assert.assertTrue(myTasksPage.verifyNewTaskDescription(actualNewTaskDescription));
    }

    @Then("^task is removed from task list$")
    public void taskIsRemovedFromTaskList() throws Throwable {
        int actualNumberOfTasks = myTasksPage.getNumberOfNewTasks();
        oountOfNewTasks--;
        Assert.assertEquals(oountOfNewTasks, actualNumberOfTasks);
    }

    @Then("^Validate Manage SubTasks button present in Task List$")
    public void validateManageSubTasksButtonPresentInTaskList() throws Throwable {
        if(myTasksPage.getNumberOfNewTasks()==0)
        {
            Assert.assertFalse(myTasksPage.validateManageSubTasksButton());
        }
        else
        {
            Assert.assertTrue(myTasksPage.validateManageSubTasksButton());
        }
    }

    @Then("^user clicks on Manage SubTasks button$")
    public void userClicksOnManageSubTasksButton() throws Throwable {
            myTasksPage.ClickOnManageSubTasksButton();
    }

    @Then("^Modal PopUp Window opens up$")
    public void modalPopUpWindowOpensUp() throws Throwable {
            myTasksPage.verifyPopUpWindow();
    }

    @Then("^user checks for task id present on popup window$")
    public void userChecksForTaskIdPresentOnPopupWindow() throws Throwable {
            myTasksPage.verifyTaskIDOnPopUpWindow();
    }

    @Then("^user checks for task description on popup window$")
    public void userChecksForTaskDescriptionOnPopupWindow() throws Throwable {
            myTasksPage.verifyTaskDescriptionOnPopUpWindow();
    }

    @Then("^user clicks on add sub task button$")
    public void userClicksOnAddSubTaskButton() throws Throwable {
            myTasksPage.clickOnAddSubTaskButton();
    }

    @Then("^new subTask should be created and appended in the task list$")
    public void newSubTaskShouldBeCreatedAndAppendedInTheTaskList() throws Throwable {
            int actualNoOfSubTask = myTasksPage.getNumberOfSubTasks();
            oountOfSubTasks++;
            Assert.assertEquals(oountOfSubTasks,actualNoOfSubTask);
    }

    @Then("^remove newly added new subTask with ([^\"]*)$")
    public void removeNewlyAddedNewSubTaskWithNewSubTaskDescription(String subTaskDescription) throws Throwable {
        String actualSubTaskDescription = myTasksPage.checkSubTaskDescription();
        myTasksPage.ClickOnRemoveSubTaskButton();
        Assert.assertTrue(myTasksPage.verifyNewTaskDescription(actualSubTaskDescription));
    }

    @Then("^user types ([^\"]*) and ([^\"]*)$")
    public void userTypesNewSubTaskDescriptionAndDueDateDetails(String subTaskDetails, String dueDateDetails) throws Throwable {
        myTasksPage.entersDetailsForSubTask(subTaskDetails,dueDateDetails);
        oountOfSubTasks = myTasksPage.getNumberOfSubTasks();
    }

    @Then("^new subTask should not be created and appended in the task list$")
    public void newSubTaskShouldNotBeCreatedAndAppendedInTheTaskList() throws Throwable {
        int actualNoOfSubTask = myTasksPage.getNumberOfSubTasks();
        Assert.assertEquals(oountOfSubTasks,actualNoOfSubTask);
    }
}
