$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Login.feature");
formatter.feature({
  "line": 1,
  "name": "Features for QA-Test-AvenueCode",
  "description": "This feature deals with all the features of the application",
  "id": "features-for-qa-test-avenuecode",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Validate My Tasks Button on Home Page",
  "description": "",
  "id": "features-for-qa-test-avenuecode;validate-my-tasks-button-on-home-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user opens browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user is on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "Validate My Tasks Button on Home page",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "close the browser",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 10,
  "name": "Validate My Tasks Button on SignIn Page",
  "description": "",
  "id": "features-for-qa-test-avenuecode;validate-my-tasks-button-on-signin-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user opens browser",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "user is on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "user clicks on SignIn button",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "SignIn page is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Validate My Tasks Button on SignIn page",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "close the browser",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 18,
  "name": "Validate My Tasks Button on Home page after SignIn",
  "description": "",
  "id": "features-for-qa-test-avenuecode;validate-my-tasks-button-on-home-page-after-signin",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user opens browser",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "user is on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "user clicks on SignIn button",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "SignIn page is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "user logs into the application",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "user is logged in and on home page",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "Validate My Tasks Button on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "user clicks on My Tasks button present on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 27,
  "name": "My Tasks Page is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 28,
  "name": "close the browser",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 30,
  "name": "Validate My Tasks Button on SignUp Page",
  "description": "",
  "id": "features-for-qa-test-avenuecode;validate-my-tasks-button-on-signup-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "user opens browser",
  "keyword": "Given "
});
formatter.step({
  "line": 32,
  "name": "user is on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "user clicks on SignUp button",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "Validate My Tasks Button on SignUp page",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "close the browser",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 37,
  "name": "Validate display message for logged in user on My Tasks page",
  "description": "",
  "id": "features-for-qa-test-avenuecode;validate-display-message-for-logged-in-user-on-my-tasks-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 38,
  "name": "user opens browser",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "user is on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "user clicks on SignIn button",
  "keyword": "And "
});
formatter.step({
  "line": 41,
  "name": "SignIn page is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "user logs into the application",
  "keyword": "And "
});
formatter.step({
  "line": 43,
  "name": "user is logged in and on home page",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "Validate My Tasks Button on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 45,
  "name": "user clicks on My Tasks button present on Home page",
  "keyword": "And "
});
formatter.step({
  "line": 46,
  "name": "My Tasks Page is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 47,
  "name": "close the browser",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});